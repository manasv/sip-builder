.. PJSUA2 documentation master file, created by
   sphinx-quickstart on Sat Nov 30 06:36:26 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

PJSUA2 Documentation
==========================================

Contents:

.. toctree::
   :maxdepth: 2
   :numbered: 1

   intro
   consider
   intro_pjsua2
   endpoint
   account
   media
   call
   presence
   samples
   media_quality
   network_problems
   reference
   breathe

   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

